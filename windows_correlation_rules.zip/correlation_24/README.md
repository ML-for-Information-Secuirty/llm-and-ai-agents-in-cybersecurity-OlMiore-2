# Unauthorized Process Modifications Detected
## Обнаружено изменение процессов

### 📝 Description (EN)
This correlation rule detects potential unauthorized modifications to processes and services on a system, which may indicate malicious activity. It is based on events from Microsoft Security and Sysmon logs.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальные неавторизованные изменения процессов и служб в системе, что может указывать на вредоносную активность. Оно основано на событиях из журналов безопасности Microsoft и Sysmon.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1543
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4688",
    "msgid": "4688",
    "time": "2023-06-05T08:46:55.3231989Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2023-06-05T08:46:55.3985456Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json, norm_fields_3_1.json, norm_fields_4_1.json
