# Privilege Escalation Detected
## Обнаружено повышение привилегий

### 📝 Description (EN)
This correlation rule detects potential privilege escalation attempts via user right assignment, as identified by MITRE technique T1068. It is triggered by Windows Security event ID 4703.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальные попытки повышения привилегий через назначение прав пользователю, определенные техникой MITRE T1068. Оно срабатывает при возникновении события безопасности Windows с идентификатором 4703.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Privilege Escalation
- **Technique:** T1068
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4703",
    "msgid": "4703",
    "time": "2023-06-01T16:16:14.2766042Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4703",
    "msgid": "4703",
    "time": "2019-08-14T12:48:15.9215075Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json
