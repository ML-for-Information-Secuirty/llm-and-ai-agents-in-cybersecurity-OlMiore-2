# System Discovery Activity Detected
## Обнаружена активность обнаружения системы

### 📝 Description (EN)
This correlation rule detects potential system discovery activity by analyzing process creation events from Sysmon. It identifies repeated process discovery attempts within a short time frame.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальную активность обнаружения системы, анализируя события создания процессов из Sysmon. Оно выявляет повторные попытки обнаружения процессов в короткий период времени.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Discovery
- **Technique:** T1057 - Process Discovery
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2019-08-03T12:06:55.6206002Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2019-08-03T12:06:55.8204069Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json
