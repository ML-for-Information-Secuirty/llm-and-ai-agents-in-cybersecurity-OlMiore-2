# LSASS Dumping Detection Alert
## Обнаружение дампа LSASS

### 📝 Description (EN)
This correlation rule detects potential LSASS dumping activity, which may indicate credential access attempts. It is based on the MITRE T1003.001 technique.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальную активность дампа LSASS, которая может указывать на попытки доступа к учетным данным. Оно основано на технике MITRE T1003.001.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Credential Access
- **Technique:** T1003.001
- **Importance:** 3

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "PC04.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "10",
    "msgid": "10",
    "time": "2019-03-17T19:09:41.3288680Z",
    "event_src.subsys": "Sysmon",
    "subject.process.fullpath": "C:\\Users\\IEUser\\Desktop\\procdump.exe",
    "subject.process.name": "procdump.exe",
    "subject.process.path": "C:/Users/IEUser/Desktop/",
    "subject.process.id": "1856",
    "object.process.fullpath": "C:\\Windows\\system32\\lsass.exe",
    "object.process.name": "lsass.exe",
    "object.process.path": "C:/Windows/system32/",
    "object.process.id": "476"
  },
  {
    "event_src.host": "PC04.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "11",
    "msgid": "11",
    "time": "2019-03-17T19:09:41.3288680Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json
