# Registry Modification Detected
## Обнаружено изменение реестра

### 📝 Description (EN)
This correlation rule detects potential registry modifications, which may indicate an attempt to evade defense mechanisms. The rule is based on event ID 4657 from Microsoft Security events.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальные изменения реестра, которые могут указывать на попытку обойти механизмы защиты. Правило основано на событии 4657 из событий безопасности Microsoft.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Defense Evasion
- **Technique:** T1070.001
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4657",
    "msgid": "4657",
    "time": "2024-06-04T18:55:19.4532906Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_3_1.json
