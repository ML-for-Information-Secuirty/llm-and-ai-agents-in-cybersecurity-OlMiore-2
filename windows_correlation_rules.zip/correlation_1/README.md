# Malicious Process Creation Detected
## Обнаружено создание вредоносного процесса

### 📝 Description (EN)
This correlation rule detects potential malicious process creation as described in MITRE technique T1566.001, which may indicate an attacker attempting to execute malicious code on a compromised system.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное создание вредоносного процесса, описанное в технике MITRE T1566.001, что может указывать на попытку злоумышленника выполнить вредоносный код на скомпрометированной системе.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1566.001
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "PC1",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2023-07-01T05:26:07.5392352Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
