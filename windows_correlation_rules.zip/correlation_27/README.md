# Windows Service Creation Detected
## Обнаружено создание службы Windows

### 📝 Description (EN)
This correlation rule detects potential Windows service creation, which may indicate a privilege escalation attempt. It is based on Windows Security event logs with IDs 4624 and 4648.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное создание службы Windows, которое может указывать на попытку повышения привилегий. Оно основано на журналах безопасности Windows с идентификаторами событий 4624 и 4648.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Privilege Escalation
- **Technique:** T1548.003 - Windows Service Creation
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4624",
    "msgid": "4624",
    "time": "2020-09-15T18:04:39.9871239Z",
    "event_src.subsys": "Security",
    "subject.account.id": "S-1-5-21-3461203602-4096304019-2269080069-1000",
    "subject.account.name": "IEUser",
    "subject.account.domain": "MSEDGEWIN10",
    "subject.account.session_id": "0x22afa1",
    "object.account.id": "S-1-5-21-3461203602-4096304019-2269080069-1009",
    "object.account.name": "svc01",
    "object.account.domain": "MSEDGEWIN10",
    "object.account.session_id": "0x10b6b3",
    "subject.process.id": "0x140c",
    "subject.process.fullpath": "C:\\Windows\\System32\\inetsrv\\w3wp.exe",
    "subject.process.name": "w3wp.exe",
    "subject.process.path": "C:/Windows/System32/inetsrv/"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4648",
    "msgid": "4648",
    "time": "2020-09-15T18:04:39.9870522Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json, norm_fields_2_1.json, norm_fields_2_2.json
