# C2 Communication Detection Alert
## Обнаружение связи C2

### 📝 Description (EN)
This correlation rule detects potential Command and Control (C2) communication based on Sysmon events. It identifies suspicious network activity that may indicate malware communication with its command center.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальную связь команды и управления (C2) на основе событий Sysmon. Оно выявляет подозрительную сетевую активность, которая может указывать на связь вредоносного ПО с его командным центром.

---

### 🔥 MITRE ATT&CK
- **Tactic:** TA0011
- **Technique:** T1071
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "3",
    "msgid": "3",
    "time": "2019-09-03T11:04:07.2070493Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "3",
    "msgid": "3",
    "time": "2019-09-03T11:04:07.2071312Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json, norm_fields_2_1.json, norm_fields_2_2.json
