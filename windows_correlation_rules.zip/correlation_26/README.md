# System Monitoring Detection
## Обнаружение мониторинга системы

### 📝 Description (EN)
This correlation rule detects potential system monitoring activities based on Sysmon event ID 1. It indicates a possible attempt to gather information about the system.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальную деятельность по мониторингу системы на основе события Sysmon с ID 1. Оно указывает на возможную попытку сбора информации о системе.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Discovery
- **Technique:** T1057
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "IEWIN7",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2019-05-09T01:59:29.0908971Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
