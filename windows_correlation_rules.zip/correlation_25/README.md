# PowerShell Malicious Activity Detected
## Обнаружена вредоносная активность PowerShell

### 📝 Description (EN)
This correlation rule detects potential malicious activity related to PowerShell, as identified by MITRE technique T1059. It aggregates relevant events from Microsoft-Windows-PowerShell and Sysmon to identify suspicious behavior.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальную вредоносную активность, связанную с PowerShell, как определено техникой MITRE T1059. Оно агрегирует соответствующие события из Microsoft-Windows-PowerShell и Sysmon, чтобы выявить подозрительное поведение.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1059
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "Test_w10x64-130.testlab.org",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2021-08-16T13:16:24.2433848Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "Test_w10x64-130.testlab.org",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4104",
    "msgid": "4104",
    "time": "2021-08-16T13:16:24.2372357Z",
    "event_src.subsys": "Microsoft-Windows-PowerShell"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json, norm_fields_3_1.json
