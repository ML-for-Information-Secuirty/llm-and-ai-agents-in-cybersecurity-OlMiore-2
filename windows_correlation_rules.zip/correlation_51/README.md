# Code Injection Attempt Detected
## Обнаружена попытка внедрения кода

### 📝 Description (EN)
This correlation rule detects potential code injection attempts as identified by the MITRE technique T1055, which is a Defense Evasion tactic. It is triggered by a specific event from the Microsoft Operating System.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальные попытки внедрения кода, выявленные техникой MITRE T1055, которая является тактикой обхода защиты. Оно срабатывает при возникновении конкретного события из операционной системы Microsoft.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Defense Evasion
- **Technique:** T1055
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "IEWIN7",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "8",
    "msgid": "8",
    "time": "2019-04-30T07:26:34.1336380Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
