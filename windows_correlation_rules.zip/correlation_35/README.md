# Malicious Process Execution Detected
## Обнаружено вредоносное выполнение процесса

### 📝 Description (EN)
This correlation rule detects potential malicious process execution and registry modification based on Sysmon events. It identifies suspicious activity that may indicate an attacker's attempt to execute malicious code.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное вредоносное выполнение процесса и модификацию реестра на основе событий Sysmon. Оно выявляет подозрительную активность, которая может указывать на попытку злоумышленника выполнить вредоносный код.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1204
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "IEWIN7",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "13",
    "msgid": "13",
    "time": "2019-05-09T01:59:28.6690221Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "IEWIN7",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2019-05-09T01:59:29.0908971Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json
