# Valid Account Login Attempt
## Попытка входа с валидным аккаунтом

### 📝 Description (EN)
This correlation rule detects potential login attempts using valid credentials, as identified by MITRE technique T1078. It is triggered by Windows Security event IDs 4624 and 4625.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальные попытки входа с использованием валидных учетных данных, определенных техникой MITRE T1078. Оно срабатывает при событиях безопасности Windows с идентификаторами 4624 и 4625.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Initial Access
- **Technique:** T1078: Valid Accounts
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4625",
    "msgid": "4625",
    "time": "2020-09-09T13:18:23.6279525Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4624",
    "msgid": "4624",
    "time": "2020-09-09T13:18:27.7146132Z",
    "event_src.subsys": "Security",
    "subject.account.id": "S-1-5-21-3461203602-4096304019-2269080069-1000",
    "subject.account.name": "IEUser",
    "subject.account.domain": "MSEDGEWIN10",
    "subject.account.session_id": "0x1cd8f6",
    "object.account.id": "S-1-5-21-3461203602-4096304019-2269080069-1000",
    "object.account.name": "IEUser",
    "object.account.domain": "MSEDGEWIN10",
    "object.account.session_id": "0x79e59",
    "subject.process.id": "0x1358",
    "subject.process.fullpath": "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    "subject.process.name": "chrome.exe",
    "subject.process.path": "C:/Program Files (x86)/Google/Chrome/Application/"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json
