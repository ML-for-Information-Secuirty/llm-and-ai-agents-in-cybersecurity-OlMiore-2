# Privilege Escalation Detection
## Обнаружение повышения привилегий

### 📝 Description (EN)
This correlation rule detects potential privilege escalation attempts via logon events, as described in MITRE technique T1078. It analyzes security logs from Windows systems to identify suspicious activity.

### 📝 Описание (RU)
Этот корреляционный правил обнаруживает потенциальные попытки повышения привилегий через события входа в систему, как описано в технике MITRE T1078. Он анализирует журналы безопасности систем Windows, чтобы выявить подозрительную активность.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Privilege Escalation
- **Technique:** T1078
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "dc01.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "5145",
    "msgid": "5145",
    "time": "2023-06-13T08:03:45.1093750Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "dc01.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4672",
    "msgid": "4672",
    "time": "2023-06-13T08:03:45.0937500Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json, norm_fields_1_3.json, norm_fields_2_1.json, norm_fields_2_2.json, norm_fields_2_3.json
