# LSASS Memory Dump Attempt
## Попытка дампа памяти LSASS

### 📝 Description (EN)
This correlation rule detects a potential LSASS memory dump via rundll32.exe, which may indicate a credential access attempt. The rule is based on Sysmon events related to process creation and access to lsass.exe.

### 📝 Описание (RU)
Этот корреляционный правил обнаруживает потенциальную попытку дампа памяти LSASS через rundll32.exe, что может указывать на попытку доступа к учетным данным. Правило основано на событиях Sysmon, связанных с созданием процессов и доступом к lsass.exe.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Credential Access
- **Technique:** T1003.001
- **Importance:** 3

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2019-08-30 12:54:07.873791",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "7",
    "msgid": "7",
    "time": "2019-08-30 12:54:08.171875",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json, norm_fields_1_3.json, norm_fields_1_4.json, norm_fields_1_5.json, norm_fields_1_6.json, norm_fields_2_1.json, norm_fields_2_2.json, norm_fields_2_3.json, norm_fields_2_4.json, norm_fields_2_5.json
