# Mimikatz Credential Dumping Detected
## Обнаружено сброс凭证 с помощью Mimikatz

### 📝 Description (EN)
This correlation rule detects potential credential dumping via Mimikatz, a popular tool used for extracting credentials from the LSASS process. It triggers when suspicious activity is detected involving the mimikatz.exe process and the lsass.exe process.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальный сброс凭证 с помощью Mimikatz, популярного инструмента для извлечения凭证 из процесса LSASS. Оно срабатывает, когда обнаруживается подозрительная активность, связанная с процессом mimikatz.exe и процессом lsass.exe.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Credential Access
- **Technique:** T1003.001
- **Importance:** 3

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "PC04.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "10",
    "msgid": "10",
    "time": "2019-03-17T19:37:11.6619304Z",
    "event_src.subsys": "Sysmon",
    "subject.process.fullpath": "C:\\Users\\IEUser\\Desktop\\mimikatz_trunk\\Win32\\mimikatz.exe",
    "subject.process.name": "mimikatz.exe",
    "subject.process.path": "C:/Users/IEUser/Desktop/mimikatz_trunk/Win32/",
    "subject.process.id": "3588",
    "object.process.fullpath": "C:\\Windows\\system32\\lsass.exe",
    "object.process.name": "lsass.exe",
    "object.process.path": "C:/Windows/system32/",
    "object.process.id": "476"
  },
  {
    "event_src.host": "dc1.lab.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4663",
    "msgid": "4663",
    "time": "2023-06-09T19:34:19.602076800Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json
