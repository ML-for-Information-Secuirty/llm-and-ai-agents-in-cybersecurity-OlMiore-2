# Suspicious Service Creation Detected
## Обнаружено подозрительное создание службы

### 📝 Description (EN)
This correlation rule detects potential defense evasion techniques by identifying suspicious service creation and modification events on a system. It monitors for specific event IDs from Sysmon and Service Control Manager to identify potentially malicious activity.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальные техники обхода защиты, выявляя подозрительные события создания и модификации служб в системе. Оно отслеживает определенные идентификаторы событий из Sysmon и Service Control Manager, чтобы выявить потенциально вредоносную активность.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Defense Evasion
- **Technique:** T1562.001
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "Win10x64-133.testlab.esc",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "17",
    "msgid": "17",
    "time": "2023-05-17T10:24:33.2700764Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "Win10x64-133.testlab.esc",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "18",
    "msgid": "18",
    "time": "2023-05-17T10:24:33.2963447Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json, norm_fields_1_3.json, norm_fields_2_1.json, norm_fields_2_2.json, norm_fields_2_3.json, norm_fields_3_1.json, norm_fields_3_2.json, norm_fields_3_3.json
