# LSASS Memory Dump Detected
## Обнаружан дамп памяти LSASS

### 📝 Description (EN)
This correlation rule detects potential LSASS memory dump attempts, which may indicate credential access attacks. The rule is based on Windows security event logs and Sysmon events.

### 📝 Описание (RU)
Этот корреляционный правил обнаруживает потенциальные попытки дампа памяти LSASS, которые могут указывать на атаки с доступом к учетным данным. Правило основано на журналах безопасности Windows и событиях Sysmon.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Credential Access
- **Technique:** T1003.001
- **Importance:** 3

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4656",
    "msgid": "4656",
    "time": "2020-03-08T22:11:34.3404793Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4663",
    "msgid": "4663",
    "time": "2020-03-08T22:11:34.3405849Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json, norm_fields_2_1.json, norm_fields_3_1.json, norm_fields_4_1.json
