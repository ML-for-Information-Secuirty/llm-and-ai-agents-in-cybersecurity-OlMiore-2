# Malicious Code Execution Detected
## Обнаружено выполнение вредоносного кода

### 📝 Description (EN)
Potential malicious code execution via process creation and image loading detected on host LAPTOP-JU4M3I0E. This may indicate a security threat.

### 📝 Описание (RU)
Обнаружено потенциальное выполнение вредоносного кода через создание процессов и загрузку изображений на хосте LAPTOP-JU4M3I0E. Это может указывать на угрозу безопасности.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1204
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "LAPTOP-JU4M3I0E",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "7",
    "msgid": "7",
    "time": "2020-10-13T20:11:42.2692242Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "LAPTOP-JU4M3I0E",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2020-10-13T20:11:42.2786722Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json
