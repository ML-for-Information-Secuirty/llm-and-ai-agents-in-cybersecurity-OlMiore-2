# Sysmon and Security Log Tampering
## Вмешательство в журналы Sysmon и Security

### 📝 Description (EN)
Detection of potential tampering with Sysmon and Security logs, which may indicate defense evasion techniques. This correlation rule alerts on suspicious events from Microsoft Operating System sources.

### 📝 Описание (RU)
Обнаружение потенциального вмешательства в журналы Sysmon и Security, которое может указывать на использование техник обхода защиты. Этот корреляционный规칙 оповещает о подозрительных событиях из источников операционной системы Microsoft.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Defense Evasion
- **Technique:** T1562.006
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "13",
    "msgid": "13",
    "time": "2024-06-04T20:00:27.7010188Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4657",
    "msgid": "4657",
    "time": "2024-06-04T19:54:04.8131440Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_4_1.json, norm_fields_5_1.json
