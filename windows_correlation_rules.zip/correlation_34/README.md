# Sysmon Config Modification Detected
## Обнаружено изменение конфигурации Sysmon

### 📝 Description (EN)
This correlation rule detects potential modifications to the Sysmon configuration, which could be used for defense evasion tactics. It is based on event ID 13 from the Microsoft Sysmon event log.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальные изменения конфигурации Sysmon, которые могут использоваться для тактик обхода защиты. Оно основано на событии ID 13 из журнала событий Microsoft Sysmon.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Defense Evasion
- **Technique:** T1562.006
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "IEWIN7",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "13",
    "msgid": "13",
    "time": "2019-05-10T12:21:57.2866667Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
