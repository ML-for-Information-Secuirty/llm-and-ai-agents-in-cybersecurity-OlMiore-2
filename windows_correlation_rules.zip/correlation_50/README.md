# Command Line Execution Detected
## Обнаружено выполнение командной строки

### 📝 Description (EN)
This correlation rule detects potential command line execution on a Windows system, indicating a possible malicious activity. It is based on events from Microsoft Security and Sysmon logs.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное выполнение командной строки в системе Windows, что может указывать на возможную вредоносную активность. Оно основано на событиях из журналов безопасности Microsoft и Sysmon.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1059
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4688",
    "msgid": "4688",
    "time": "2024-07-16T08:43:42.9578115Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2024-07-16T08:43:42.9794606Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json
