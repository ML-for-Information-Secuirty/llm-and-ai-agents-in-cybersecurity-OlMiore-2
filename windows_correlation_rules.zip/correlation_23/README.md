# Suspicious Process Creation Detected
## Обнаружено Создание Процесса

### 📝 Description (EN)
This correlation rule detects the creation of a new process, which may indicate potential malicious activity. It is based on the MITRE technique T1055, Process Creation.

### 📝 Описание (RU)
Это правило корреляции обнаруживает создание нового процесса, которое может указывать на потенциально вредоносную активность. Оно основано на технике MITRE T1055, Создание Процесса.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1055
- **Importance:** 1

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "IEWIN7",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2019-05-28T02:14:50.4136318Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
