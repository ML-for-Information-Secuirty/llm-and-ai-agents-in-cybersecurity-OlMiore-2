# Multiple Logon Attempts Detected
## Обнаружены Множественные Входы

### 📝 Description (EN)
This correlation rule detects multiple logon attempts using valid accounts, which may indicate a potential security threat. The rule is based on Windows Security event ID 4799.

### 📝 Описание (RU)
Это правило корреляции обнаруживает множественные попытки входа с использованием действительных учетных записей, что может указывать на потенциальную угрозу безопасности. Правило основано на идентификаторе события безопасности Windows 4799.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Credential Access
- **Technique:** T1078 - Valid Accounts
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "01566s-win16-ir.threebeesco.com",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4799",
    "msgid": "4799",
    "time": "2023-01-24T11:52:02.1550291Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "01566s-win16-ir.threebeesco.com",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4799",
    "msgid": "4799",
    "time": "2023-01-24T11:52:02.1550291Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json, norm_fields_2_2.json, norm_fields_2_3.json, norm_fields_2_4.json, norm_fields_2_5.json
