# LSASS Memory Dumping Attempt
## Попытка дампа памяти LSASS

### 📝 Description (EN)
This correlation rule detects potential LSASS memory dumping attempts, which may indicate credential access attacks. It is based on the T1003.001 technique from the MITRE ATT&CK framework.

### 📝 Описание (RU)
Этот корреляционный правил обнаруживает потенциальные попытки дампа памяти LSASS, которые могут указывать на атаки с целью получения доступа к учетным данным. Он основан на технике T1003.001 из框架 MITRE ATT&CK.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Credential Access
- **Technique:** T1003.001
- **Importance:** 3

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2021-04-22T22:09:25.3896334Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "10",
    "msgid": "10",
    "time": "2021-04-22T22:09:25.4177398Z",
    "event_src.subsys": "Sysmon",
    "subject.process.fullpath": "c:\\Users\\IEUser\\Desktop\\PPLdump.exe",
    "subject.process.name": "PPLdump.exe",
    "subject.process.path": "c:/Users/IEUser/Desktop/",
    "subject.process.id": "6316",
    "object.process.fullpath": "C:\\Windows\\system32\\lsass.exe",
    "object.process.name": "lsass.exe",
    "object.process.path": "C:/Windows/system32/",
    "object.process.id": "652"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json, norm_fields_2_1.json, norm_fields_2_2.json, norm_fields_2_3.json, norm_fields_3_1.json, norm_fields_3_2.json, norm_fields_3_3.json, norm_fields_4_1.json, norm_fields_4_2.json
