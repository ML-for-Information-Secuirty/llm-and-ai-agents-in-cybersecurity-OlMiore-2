# Multiple Process Creation Events
## Множественные события создания процессов

### 📝 Description (EN)
This correlation rule detects multiple process creation events across different hosts, which may indicate a potential security threat. The rule is based on events from Microsoft operating system logs.

### 📝 Описание (RU)
Это правило корреляции обнаруживает множественные события создания процессов на разных хостах, что может указывать на потенциальную угрозу безопасности. Правило основано на событиях из журналов операционной системы Microsoft.

---

### 🔥 MITRE ATT&CK
- **Tactic:** TA0002
- **Technique:** T1055
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "WIN10X64-133.testlab.org",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4688",
    "msgid": "4688",
    "time": "2020-01-23T10:18:31.616030800Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "Test_w7x64-131.testlab.org",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2021-09-06T17:42:56.157650300Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json, norm_fields_3_1.json
