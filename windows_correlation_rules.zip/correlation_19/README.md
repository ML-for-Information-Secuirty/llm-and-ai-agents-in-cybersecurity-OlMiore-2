# PowerShell Script Execution Detected
## Обнаружено выполнение скрипта PowerShell

### 📝 Description (EN)
This correlation rule detects potential PowerShell script execution, which may indicate malicious activity. It is based on event ID 4104 from Microsoft-Windows-PowerShell.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное выполнение скрипта PowerShell, которое может указывать на вредоносную активность. Оно основано на идентификаторе события 4104 из Microsoft-Windows-PowerShell.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1059
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4104",
    "msgid": "4104",
    "time": "2019-09-09T13:35:09.3152300Z",
    "event_src.subsys": "Microsoft-Windows-PowerShell"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
