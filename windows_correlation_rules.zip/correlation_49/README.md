# Malicious Process Spawning Detected
## Обнаружено создание вредоносного процесса

### 📝 Description (EN)
This correlation rule detects potential malicious process spawning activity, as identified by MITRE technique T1204. It is triggered by a series of events indicating suspicious process creation.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальную активность создания вредоносных процессов, определённую техникой MITRE T1204. Оно срабатывает при серии событий, указывающих на подозрительное создание процессов.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1204
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "IEWIN7",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "10",
    "msgid": "10",
    "time": "2019-07-03T20:39:30.2547335Z",
    "event_src.subsys": "Sysmon",
    "subject.process.fullpath": "C:\\Windows\\system32\\notepad.exe",
    "subject.process.name": "notepad.exe",
    "subject.process.path": "C:/Windows/system32/",
    "subject.process.id": "1632",
    "object.process.fullpath": "C:\\Windows\\system32\\rundll32.exe",
    "object.process.name": "rundll32.exe",
    "object.process.path": "C:/Windows/system32/",
    "object.process.id": "2328"
  },
  {
    "event_src.host": "IEWIN7",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2019-07-03T20:39:30.2547335Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json, norm_fields_1_3.json
