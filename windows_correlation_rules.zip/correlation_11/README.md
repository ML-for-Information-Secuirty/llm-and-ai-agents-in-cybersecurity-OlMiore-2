# Multiple Object Access Attempts
## Множественные попытки доступа

### 📝 Description (EN)
This correlation rule detects multiple attempts to access objects, which may indicate a privilege escalation attack. The rule is based on Windows Security event ID 4662.

### 📝 Описание (RU)
Этот корреляционный правил обнаруживает множественные попытки доступа к объектам, что может указывать на атаку привилегированного расширения. Правило основано на идентификаторе события безопасности Windows 4662.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Privilege Escalation
- **Technique:** T1068
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "DC1.insecurebank.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4662",
    "msgid": "4662",
    "time": "2019-05-08T02:10:43.4872170Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "DC1.insecurebank.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4662",
    "msgid": "4662",
    "time": "2019-05-08T02:10:43.4872170Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json, norm_fields_3_1.json, norm_fields_4_1.json, norm_fields_5_1.json, norm_fields_6_1.json
