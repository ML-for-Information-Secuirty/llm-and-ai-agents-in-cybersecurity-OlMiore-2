# Multiple Process Creation Detected
## Обнаружено создание процессов

### 📝 Description (EN)
This correlation rule detects multiple process creation events, which may indicate malicious activity. The rule is based on the MITRE technique T1055, related to the Execution tactic.

### 📝 Описание (RU)
Этот корреляционный правил обнаруживает множественные события создания процессов, что может указывать на вредоносную активность. Правило основано на технике MITRE T1055, связанной с тактикой Execution.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1055
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2020-04-25T22:21:19.6296306Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2020-04-25T22:20:16.1654826Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_10.json, norm_fields_1_11.json, norm_fields_1_12.json, norm_fields_1_13.json, norm_fields_1_14.json, norm_fields_1_15.json, norm_fields_1_16.json, norm_fields_1_17.json, norm_fields_1_18.json, norm_fields_1_19.json, norm_fields_1_2.json, norm_fields_1_20.json, norm_fields_1_21.json, norm_fields_1_22.json, norm_fields_1_23.json, norm_fields_1_24.json, norm_fields_1_25.json, norm_fields_1_26.json, norm_fields_1_27.json, norm_fields_1_28.json, norm_fields_1_29.json, norm_fields_1_3.json, norm_fields_1_30.json, norm_fields_1_31.json, norm_fields_1_32.json, norm_fields_1_33.json, norm_fields_1_34.json, norm_fields_1_35.json, norm_fields_1_36.json, norm_fields_1_37.json, norm_fields_1_38.json, norm_fields_1_39.json, norm_fields_1_4.json, norm_fields_1_40.json, norm_fields_1_41.json, norm_fields_1_42.json, norm_fields_1_43.json, norm_fields_1_44.json, norm_fields_1_45.json, norm_fields_1_46.json, norm_fields_1_47.json, norm_fields_1_48.json, norm_fields_1_49.json, norm_fields_1_5.json, norm_fields_1_50.json, norm_fields_1_51.json, norm_fields_1_52.json, norm_fields_1_53.json, norm_fields_1_54.json, norm_fields_1_55.json, norm_fields_1_56.json, norm_fields_1_57.json, norm_fields_1_58.json, norm_fields_1_59.json, norm_fields_1_6.json, norm_fields_1_60.json, norm_fields_1_61.json, norm_fields_1_62.json, norm_fields_1_63.json, norm_fields_1_64.json, norm_fields_1_65.json, norm_fields_1_66.json, norm_fields_1_67.json, norm_fields_1_68.json, norm_fields_1_69.json, norm_fields_1_7.json, norm_fields_1_70.json, norm_fields_1_71.json, norm_fields_1_72.json, norm_fields_1_73.json, norm_fields_1_74.json, norm_fields_1_75.json, norm_fields_1_76.json, norm_fields_1_77.json, norm_fields_1_78.json, norm_fields_1_79.json, norm_fields_1_8.json, norm_fields_1_80.json, norm_fields_1_81.json, norm_fields_1_82.json, norm_fields_1_83.json, norm_fields_1_84.json, norm_fields_1_85.json, norm_fields_1_86.json, norm_fields_1_87.json, norm_fields_1_9.json, norm_fields_2_1.json, norm_fields_3_1.json
