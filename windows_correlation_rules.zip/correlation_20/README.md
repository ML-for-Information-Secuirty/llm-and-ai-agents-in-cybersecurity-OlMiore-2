# Brute Force Attack Detected
## Обнаружена атака методом перебора

### 📝 Description (EN)
This correlation rule detects potential brute force attacks on Windows systems, indicating a possible attempt to guess or crack account credentials. The rule is triggered by a series of failed login attempts within a short time frame.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальные атаки методом перебора на системы Windows, указывая на возможную попытку угадать или взломать учетные данные. Правило срабатывает при серии неудачных попыток входа в систему в течение короткого времени.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Credential Access
- **Technique:** T1110 - Brute Force
- **Importance:** 3

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "ARM-DNS-ADMIN.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "13",
    "msgid": "13",
    "time": "2023-07-31T14:19:58.0692824Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "ARM-DNS-ADMIN.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "13",
    "msgid": "13",
    "time": "2023-07-31T14:20:03.2523474Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json, norm_fields_2_1.json, norm_fields_2_2.json, norm_fields_3_1.json, norm_fields_3_2.json, norm_fields_3_3.json, norm_fields_3_4.json, norm_fields_3_5.json, norm_fields_3_6.json, norm_fields_3_7.json
