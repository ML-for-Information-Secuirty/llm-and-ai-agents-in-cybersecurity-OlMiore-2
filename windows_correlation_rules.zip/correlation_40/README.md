# Multiple File Share Access
## Множественный доступ к файлам

### 📝 Description (EN)
Detection of multiple attempts to access file shares, indicating potential discovery tactics by an adversary. This correlation rule triggers when multiple events of type 5145 are detected from the same host.

### 📝 Описание (RU)
Обнаружение множественных попыток доступа к файловым ресурсам, указывающее на потенциальные тактики обнаружения злоумышленником. Этот корреляционный правил срабатывает, когда обнаруживается несколько событий типа 5145 от одного и того же хоста.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Discovery
- **Technique:** T1201
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "WIN-77LTAPHIQ1R.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "5145",
    "msgid": "5145",
    "time": "2019-01-20T07:02:45.4093218Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "WIN-77LTAPHIQ1R.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "5145",
    "msgid": "5145",
    "time": "2019-01-20T07:02:45.4249182Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json, norm_fields_1_3.json
