# Malicious File Execution Detected
## Обнаружено выполнение вредоносного файла

### 📝 Description (EN)
This correlation rule detects potential malicious file creation using event triggered execution techniques, as described in MITRE ATT&CK T1190. It is triggered by multiple Sysmon events with event ID 11 from the same host.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное создание вредоносных файлов с использованием методов выполнения, триггерных событий, как описано в MITRE ATT&CK T1190. Оно срабатывает при нескольких событиях Sysmon с идентификатором события 11 с одного и того же хоста.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Defense Evasion
- **Technique:** T1190 - Event Triggered Execution
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "11",
    "msgid": "11",
    "time": "2020-09-11T12:10:22.3987265Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "11",
    "msgid": "11",
    "time": "2020-09-11T12:10:22.3987265Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json
