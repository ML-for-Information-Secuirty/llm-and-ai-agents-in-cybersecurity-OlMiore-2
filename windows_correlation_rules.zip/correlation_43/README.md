# PowerShell Execution Detected
## Обнаружено выполнение PowerShell

### 📝 Description (EN)
This correlation rule detects potential PowerShell and command line execution activities based on Windows event logs, indicating possible malicious activity. The rule triggers when multiple related events are observed within a short time frame.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное выполнение PowerShell и командной строки на основе журналов событий Windows, указывающее на возможную вредоносную активность. Правило срабатывает, когда в течение короткого времени наблюдаются несколько связанных событий.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1059
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "pc.domain.loc",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4104",
    "msgid": "4104",
    "time": "2023-06-27T03:33:34.168514100Z",
    "event_src.subsys": "Microsoft-Windows-PowerShell"
  },
  {
    "event_src.host": "pc.domain.loc",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4104",
    "msgid": "4104",
    "time": "2023-06-28T04:57:41.980608100Z",
    "event_src.subsys": "Microsoft-Windows-PowerShell"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json, norm_fields_3_1.json, norm_fields_4_1.json, norm_fields_5_1.json
