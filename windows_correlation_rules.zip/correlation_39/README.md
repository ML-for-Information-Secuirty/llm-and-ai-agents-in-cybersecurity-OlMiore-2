# Lateral Movement Detection Alert
## Обнаружение перемещения по сети

### 📝 Description (EN)
This correlation rule detects potential lateral movement via remote services, as identified by MITRE technique T1021. It analyzes security and sysmon events from Microsoft operating systems to identify suspicious activity.

### 📝 Описание (RU)
Этот корреляционный правил обнаруживает потенциальное перемещение по сети через удаленные сервисы, идентифицированные техникой MITRE T1021. Он анализирует события безопасности и sysmon из операционных систем Microsoft, чтобы выявить подозрительную активность.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Lateral Movement
- **Technique:** T1021
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4688",
    "msgid": "4688",
    "time": "2024-07-04T09:21:47.4363990Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2024-07-04T09:14:07.8141493Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json, norm_fields_3_1.json, norm_fields_4_1.json, norm_fields_4_2.json, norm_fields_4_3.json
