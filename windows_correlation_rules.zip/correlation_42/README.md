# Suspicious Process Termination Detected
## Обнаружено подозрительное завершение процесса

### 📝 Description (EN)
This correlation rule detects potential malicious activity by identifying suspicious process termination events, which may indicate an attacker's attempt to evade detection. The rule is based on the MITRE technique T1055.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальную вредоносную активность, определяя подозрительные события завершения процесса, которые могут указывать на попытку атакующего избежать обнаружения. Правило основано на технике MITRE T1055.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1055
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "IEWIN7",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "13",
    "msgid": "13",
    "time": "2019-05-24 15:38:21.485899",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
