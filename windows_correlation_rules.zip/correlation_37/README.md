# Command Line Execution Detected
## Обнаружено выполнение командной строки

### 📝 Description (EN)
This correlation rule detects potential command line execution via Sysmon events, indicating a possible attack vector. It is based on the MITRE technique T1204, which is associated with the Execution tactic.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное выполнение командной строки через события Sysmon, указывающее на возможный вектор атаки. Оно основано на технике MITRE T1204, связанной с тактикой выполнения.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1204
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2019-08-03T12:08:55.4089224Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "7",
    "msgid": "7",
    "time": "2019-08-03T12:08:19.8880688Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_10.json, norm_fields_1_11.json, norm_fields_1_12.json, norm_fields_1_13.json, norm_fields_1_14.json, norm_fields_1_15.json, norm_fields_1_16.json, norm_fields_1_17.json, norm_fields_1_18.json, norm_fields_1_19.json, norm_fields_1_2.json, norm_fields_1_3.json, norm_fields_1_4.json, norm_fields_1_5.json, norm_fields_1_6.json, norm_fields_1_7.json, norm_fields_1_8.json, norm_fields_1_9.json, norm_fields_2_1.json, norm_fields_2_10.json, norm_fields_2_11.json, norm_fields_2_12.json, norm_fields_2_13.json, norm_fields_2_14.json, norm_fields_2_15.json, norm_fields_2_16.json, norm_fields_2_17.json, norm_fields_2_18.json, norm_fields_2_19.json, norm_fields_2_2.json, norm_fields_2_3.json, norm_fields_2_4.json, norm_fields_2_5.json, norm_fields_2_6.json, norm_fields_2_7.json, norm_fields_2_8.json, norm_fields_2_9.json, norm_fields_3_1.json, norm_fields_3_2.json
