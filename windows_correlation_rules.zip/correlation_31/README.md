# Admin Logon Detection
## Обнаружение входа админа

### 📝 Description (EN)
This correlation rule detects successful logon events with administrator accounts, which could indicate potential initial access attempts. It is based on Windows Security event ID 4624.

### 📝 Описание (RU)
Это правило корреляции обнаруживает успешные события входа с учетными записями администратора, что может указывать на потенциальные попытки первоначального доступа. Оно основано на идентификаторе события безопасности Windows 4624.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Initial Access
- **Technique:** T1078 - Valid Accounts
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "02694w-win10.threebeesco.com",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4624",
    "msgid": "4624",
    "time": "2022-04-25T22:17:47.0581723Z",
    "event_src.subsys": "Security",
    "subject.account.id": "S-1-5-21-308926384-506822093-3341789130-500",
    "subject.account.name": "Administrator",
    "subject.account.domain": "THREEBEESCO.COM",
    "subject.account.session_id": "0x8a38de",
    "object.account.id": "S-1-0-0",
    "object.account.name": "-",
    "object.account.domain": "-",
    "object.account.session_id": "0x0",
    "subject.process.id": "0x0",
    "subject.process.fullpath": "-",
    "subject.process.name": "-",
    "subject.process.path": "-"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
