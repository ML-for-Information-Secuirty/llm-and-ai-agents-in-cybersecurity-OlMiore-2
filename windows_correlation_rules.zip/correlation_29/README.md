# Privilege Escalation via Logon Attempt
## Возведение привилегий через вход

### 📝 Description (EN)
This correlation rule detects potential privilege escalation attempts via logon events, indicating a possible security threat. It is based on MITRE technique T1078.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальные попытки повышения привилегий через события входа, указывающие на возможную угрозу безопасности. Оно основано на технике MITRE T1078.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Privilege Escalation
- **Technique:** T1078
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "PC01.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4624",
    "msgid": "4624",
    "time": "2019-03-18T11:06:29.9115792Z",
    "event_src.subsys": "Security",
    "subject.account.id": "S-1-5-21-1587066498-1489273250-1035260531-1106",
    "subject.account.name": "user01",
    "subject.account.domain": "EXAMPLE",
    "subject.account.session_id": "0x4530f0f",
    "object.account.id": "S-1-5-21-1587066498-1489273250-1035260531-1106",
    "object.account.name": "user01",
    "object.account.domain": "EXAMPLE",
    "object.account.session_id": "0x18a7875",
    "subject.process.id": "0x3ec",
    "subject.process.fullpath": "C:\\Windows\\System32\\svchost.exe",
    "subject.process.name": "svchost.exe",
    "subject.process.path": "C:/Windows/System32/"
  },
  {
    "event_src.host": "PC01.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4672",
    "msgid": "4672",
    "time": "2019-03-18T11:06:29.9115792Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json
