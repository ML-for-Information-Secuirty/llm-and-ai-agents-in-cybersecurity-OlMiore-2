# PowerShell Logging Tampering Detected
## Обнаружено нарушение журналирования PowerShell

### 📝 Description (EN)
This correlation rule detects potential tampering with PowerShell logging, which may indicate an attempt to evade defenses. The rule is triggered by a Windows event ID 4104 from the Microsoft-Windows-PowerShell subsystem.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное нарушение журналирования PowerShell, которое может указывать на попытку обойти защитные меры. Правило срабатывает при получении события Windows с идентификатором 4104 из подсистемы Microsoft-Windows-PowerShell.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Defense Evasion
- **Technique:** T1562.001 - Impair Defenses: Disable or Modify Tools
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4104",
    "msgid": "4104",
    "time": "2020-06-30T14:24:08.2546050Z",
    "event_src.subsys": "Microsoft-Windows-PowerShell"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
