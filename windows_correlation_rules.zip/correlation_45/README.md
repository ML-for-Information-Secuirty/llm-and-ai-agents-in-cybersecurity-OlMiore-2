# Malicious DLL Loading Detected
## Обнаружено вредоносное DLL

### 📝 Description (EN)
This correlation rule detects potential malicious DLL loading activity, which may indicate an attempt to execute malicious code. It is based on the MITRE technique T1204.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальную вредоносную загрузку DLL, которая может указывать на попытку выполнить вредоносный код. Оно основано на технике MITRE T1204.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1204
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "02694w-win10.threebeesco.com",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "7",
    "msgid": "7",
    "time": "2020-10-06T21:40:30.9100858Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
