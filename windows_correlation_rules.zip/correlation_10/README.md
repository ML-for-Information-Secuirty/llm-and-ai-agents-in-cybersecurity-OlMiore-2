# Repeated Access to Sensitive Objects
## Повторные доступы к чувствительным объектам

### 📝 Description (EN)
This correlation rule detects repeated access attempts to sensitive objects, which may indicate a potential security threat. The rule is based on multiple events with event ID 4663 from the Microsoft Security log.

### 📝 Описание (RU)
Это правило корреляции обнаруживает повторные попытки доступа к чувствительным объектам, что может указывать на потенциальную угрозу безопасности. Правило основано на нескольких событиях с идентификатором события 4663 из журнала безопасности Microsoft.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Discovery
- **Technique:** T1083
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "IEWIN7",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4663",
    "msgid": "4663",
    "time": "2019-04-27T19:33:05.3081880Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "IEWIN7",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4663",
    "msgid": "4663",
    "time": "2019-04-27T19:33:18.6997552Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_1_2.json, norm_fields_2_1.json, norm_fields_3_1.json, norm_fields_4_1.json, norm_fields_4_2.json, norm_fields_4_3.json, norm_fields_4_4.json
