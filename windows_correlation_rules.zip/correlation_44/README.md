# Account Lockout Evasion Attempt
## Попытка обхода блокировки учетной записи

### 📝 Description (EN)
This correlation rule detects potential account lockout evasion attempts, which may indicate a privilege escalation attack. It is based on Windows Security event ID 4742.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальные попытки обхода блокировки учетной записи, которые могут указывать на атаку привилегированного эскалации. Оно основано на событии безопасности Windows с идентификатором 4742.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Privilege Escalation
- **Technique:** T1098
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "DC1.insecurebank.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4742",
    "msgid": "4742",
    "time": "2019-05-08T03:00:37.5861731Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
