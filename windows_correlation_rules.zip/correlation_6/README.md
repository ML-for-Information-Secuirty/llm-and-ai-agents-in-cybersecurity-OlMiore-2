# Remote Login via Valid Account
## Удаленный вход по валидному аккаунту

### 📝 Description (EN)
Detects potential remote login attempts using valid accounts, which may indicate an initial access tactic. This correlation rule triggers when a login event is followed by a remote connection event.

### 📝 Описание (RU)
Обнаруживает потенциальные попытки удаленного входа с использованием валидных аккаунтов, что может указывать на тактику первоначального доступа. Этот корреляционный правил срабатывает, когда событие входа в систему сопровождается событием удаленного подключения.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Initial Access
- **Technique:** T1078: Valid Accounts
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "PC02.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4624",
    "msgid": "4624",
    "time": "2019-02-13T15:26:53.3567809Z",
    "event_src.subsys": "Security",
    "subject.account.id": "S-1-5-21-3583694148-1414552638-2922671848-1000",
    "subject.account.name": "IEUser",
    "subject.account.domain": "PC02",
    "subject.account.session_id": "0x45120",
    "object.account.id": "S-1-5-18",
    "object.account.name": "PC02$",
    "object.account.domain": "EXAMPLE",
    "object.account.session_id": "0x3e7",
    "subject.process.id": "0x658",
    "subject.process.fullpath": "C:\\Windows\\System32\\winlogon.exe",
    "subject.process.name": "winlogon.exe",
    "subject.process.path": "C:/Windows/System32/"
  },
  {
    "event_src.host": "PC01.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1149",
    "msgid": "1149",
    "time": "2019-02-13T18:04:57.4523864Z",
    "event_src.subsys": "Microsoft-Windows-TerminalServices-RemoteConnectionManager"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json
