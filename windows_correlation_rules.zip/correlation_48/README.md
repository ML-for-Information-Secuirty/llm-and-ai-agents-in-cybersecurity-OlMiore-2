# Event Log Tampering Detected
## Обнаружено изменение журнала событий

### 📝 Description (EN)
Potential event log tampering detected on host PC01.example.corp, indicating possible defense evasion tactics. This correlation rule triggers on specific Windows Eventlog events.

### 📝 Описание (RU)
Обнаружено потенциальное изменение журнала событий на хосте PC01.example.corp, что может указывать на попытки обхода защиты. Этот корреляционный правила срабатывает на определенные события Windows Eventlog.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Defense Evasion
- **Technique:** T1070.001
- **Importance:** 3

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "PC01.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "104",
    "msgid": "104",
    "time": "2019-03-19T23:34:25.8943413Z",
    "event_src.subsys": "Microsoft-Windows-Eventlog"
  },
  {
    "event_src.host": "PC01.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "104",
    "msgid": "104",
    "time": "2019-03-19T23:34:25.8943413Z",
    "event_src.subsys": "Microsoft-Windows-Eventlog"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json, norm_fields_3_1.json
