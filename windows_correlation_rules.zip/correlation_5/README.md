# Windows Firewall Rule Modification
## Модификация правила брандмауэра Windows

### 📝 Description (EN)
Detects potential lateral movement via modification of Windows Firewall rules, which may indicate Defense Evasion tactics. This correlation rule triggers on Windows Security event 5156.

### 📝 Описание (RU)
Обнаруживает потенциальное боковое движение через модификацию правил брандмауэра Windows, что может указывать на тактику обхода защиты. Этот корреляционный правил запускается на событии безопасности Windows 5156.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Defense Evasion
- **Technique:** T1071 - Application Window Discovery
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "PC01.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "5156",
    "msgid": "5156",
    "time": "2019-02-13T18:04:01.6321208Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
