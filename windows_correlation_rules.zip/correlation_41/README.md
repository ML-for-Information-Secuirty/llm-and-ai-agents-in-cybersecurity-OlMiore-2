# Multiple Valid Account Logon Attempts
## Множественные попытки входа с валидными учетными данными

### 📝 Description (EN)
This correlation rule detects multiple logon attempts using valid accounts, which may indicate an attempt to gain unauthorized access to the system. The rule is based on Windows Security event logs with IDs 4798 and 4799.

### 📝 Описание (RU)
Это правило корреляции обнаруживает множественные попытки входа с использованием валидных учетных данных, что может указывать на попытку получить несанкционированный доступ к системе. Правило основано на журналах безопасности Windows с идентификаторами событий 4798 и 4799.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Credential Access
- **Technique:** T1078 - Valid Accounts
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4798",
    "msgid": "4798",
    "time": "2019-08-05T09:24:56.7402180Z",
    "event_src.subsys": "Security"
  },
  {
    "event_src.host": "MSEDGEWIN10",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4798",
    "msgid": "4798",
    "time": "2019-08-05T09:24:56.7742573Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json, norm_fields_3_1.json
