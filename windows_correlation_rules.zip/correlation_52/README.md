# Suspicious Registry Modifications
## Подозрительные изменения реестра

### 📝 Description (EN)
This correlation rule detects potential registry modifications for defense evasion, as identified by multiple Sysmon events with event ID 13 from the same host. These modifications may indicate malicious activity.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальные изменения реестра для обхода защиты, выявленные несколькими событиями Sysmon с идентификатором события 13 с одного и того же хоста. Эти изменения могут указывать на вредоносную активность.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Defense Evasion
- **Technique:** T1112
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "PC04.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "13",
    "msgid": "13",
    "time": "2019-03-17T20:18:05.0865600Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "PC04.example.corp",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "13",
    "msgid": "13",
    "time": "2019-03-17T20:18:09.2825936Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json, norm_fields_3_1.json, norm_fields_4_1.json
