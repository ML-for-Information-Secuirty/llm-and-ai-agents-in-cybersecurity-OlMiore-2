# New User Account Creation
## Создание нового учетной записи

### 📝 Description (EN)
Detects potential persistence via new user account creation, as identified by MITRE technique T1136. This correlation rule triggers on Windows Security event ID 4720.

### 📝 Описание (RU)
Обнаруживает потенциальную персистентность через создание новой учетной записи пользователя, определенной техникой MITRE T1136. Этот корреляционный правил срабатывает на событие безопасности Windows с идентификатором 4720.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Persistence
- **Technique:** T1136
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "01566s-win16-ir.threebeesco.com",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4720",
    "msgid": "4720",
    "time": "2020-09-16T09:31:19.1332724Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
