# Command Line Execution Detected
## Обнаружено выполнение командной строки

### 📝 Description (EN)
This correlation rule detects potential command line execution on a system, which may indicate a malicious activity. It is based on the MITRE technique T1059.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное выполнение командной строки в системе, что может указывать на вредоносную активность. Оно основано на технике MITRE T1059.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1059
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2024-07-17T19:03:51.6531584Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "win10-work.stand2008.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "4688",
    "msgid": "4688",
    "time": "2024-07-17T19:03:51.6442569Z",
    "event_src.subsys": "Security"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json
