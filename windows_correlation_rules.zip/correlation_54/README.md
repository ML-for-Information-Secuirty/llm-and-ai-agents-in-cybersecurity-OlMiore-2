# Malicious Process Creation Detected
## Обнаружено создание вредоносного процесса

### 📝 Description (EN)
This correlation rule detects potential malicious process creation as described in MITRE technique T1204. It triggers on specific operating system events from Microsoft Sysmon.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное создание вредоносных процессов, описанное в технике MITRE T1204. Оно срабатывает на конкретные события операционной системы от Microsoft Sysmon.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1204
- **Importance:** 1

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "DC1.insecurebank.local",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2019-05-19T17:32:00.4829823Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json
