# Malicious Process Creation Detected
## Обнаружено Создание Зловредного Процесса

### 📝 Description (EN)
This correlation rule detects potential malicious process creation based on Sysmon events, indicating possible execution of malicious code. It is associated with MITRE technique T1055.

### 📝 Описание (RU)
Это правило корреляции обнаруживает потенциальное создание зловредного процесса на основе событий Sysmon, указывающее на возможное выполнение зловредного кода. Оно связано с техникой MITRE T1055.

---

### 🔥 MITRE ATT&CK
- **Tactic:** Execution
- **Technique:** T1055
- **Importance:** 2

---

### 📄 Normalized Events (samples)
```json
[
  {
    "event_src.host": "PC1",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2023-07-01T07:17:17.8499733Z",
    "event_src.subsys": "Sysmon"
  },
  {
    "event_src.host": "PC1",
    "event_src.vendor": "Microsoft",
    "event_src.category": "OperatingSystem",
    "event_src.event_id": "1",
    "msgid": "1",
    "time": "2023-07-01T07:17:22.2971496Z",
    "event_src.subsys": "Sysmon"
  }
]
```

---

### 📁 Test files
- norm_fields_1_1.json, norm_fields_2_1.json
